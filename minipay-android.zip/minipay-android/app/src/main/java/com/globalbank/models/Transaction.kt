package com.globalbank.models

import java.util.Date

data class Transaction(
    val id: String = &quot;&quot;,
    val userEmail: String = &quot;&quot;,
    val type: TransactionType = TransactionType.CREDIT,
    val amount: Double = 0.0,
    val currency: String = &quot;USD&quot;,
    val method: String = &quot;&quot;,
    val description: String = &quot;&quot;,
    val status: TransactionStatus = TransactionStatus.COMPLETED,
    val date: Date = Date(),
    val invoiceId: String? = null,
    val fromAddress: String? = null,
    val toAddress: String? = null,
    val network: String? = null
)

enum class TransactionType {
    CREDIT,
    DEBIT,
    TRANSFER,
    EXCHANGE,
    MINING
}

enum class TransactionStatus {
    PENDING,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class Invoice(
    val id: String = &quot;&quot;,
    val transactionId: String = &quot;&quot;,
    val userEmail: String = &quot;&quot;,
    val amount: Double = 0.0,
    val currency: String = &quot;USD&quot;,
    val date: Date = Date(),
    val description: String = &quot;&quot;,
    val generatedBy: String = &quot;System&quot;
)