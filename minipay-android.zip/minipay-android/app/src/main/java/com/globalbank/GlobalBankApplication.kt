package com.globalbank

import android.app.Application
import android.content.Context

class GlobalBankApplication : Application() {
    
    companion object {
        lateinit var instance: GlobalBankApplication
            private set
        
        // API Configuration
        const val API_BASE_URL = "https://api.globalbank.international/v2/"
        const val OWNER_EMAIL = "adeganglobal@gmail.com"
        const val OWNER_PHONE = "+2349030377275"
        const val OWNER_NAME = "Olawale Abdul-ganiyu Adeshina"
        
        // Banking Constants
        const val DAILY_CREDIT_AMOUNT = 10.0
        const val MINING_REWARD = 0.5
        const val MINING_INTERVAL = 5000L // 5 seconds
        
        // Supported Currencies
        val SUPPORTED_CURRENCIES = listOf("USD", "EUR", "GBP", "NGN", "BTC", "ETH", "USDT")
        
        // Payment Methods
        val PAYMENT_METHODS = listOf(
            "MasterCard", "Visa", "Crypto", "Bank Transfer",
            "PayPal", "Western Union", "Skrill", "Payeer", "Coinbase"
        )
        
        // Crypto Networks
        val CRYPTO_NETWORKS = listOf(
            "Bitcoin", "Ethereum", "Blockchain", "Coinbase",
            "PayPal Crypto", "Skrill Crypto"
        )
    }
    
    override fun onCreate() {
        super.onCreate()
        instance = this
        initializeApp()
    }
    
    private fun initializeApp() {
        // Initialize database
        DatabaseManager.initialize(this)
        
        // Initialize API client
        ApiClient.initialize()
        
        // Check and start mining if enabled
        if (SettingsManager.isMiningEnabled()) {
            MiningManager.startMining()
        }
    }
    
    fun getAppContext(): Context {
        return applicationContext
    }
}